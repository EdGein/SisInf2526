create function trg_fn_valida_nif() returns trigger
    language plpgsql
as
$$
DECLARE
    v_soma    INTEGER := 0;
    v_resto   INTEGER;
    v_digito  INTEGER;
    i         INTEGER;
BEGIN
    -- Verificação estrutural: 9 dígitos numéricos
    IF NEW.nif !~ '^[0-9]{9}$' THEN
        RAISE EXCEPTION 'NIF inválido: ''%'' não tem 9 dígitos numéricos.', NEW.nif;
    END IF;

    -- Cálculo do dígito de controlo
    FOR i IN 1..8 LOOP
        v_soma := v_soma + CAST(SUBSTRING(NEW.nif FROM i FOR 1) AS INTEGER) * (10 - i);
    END LOOP;

    v_resto := v_soma % 11;

    IF v_resto = 0 OR v_resto = 1 THEN
        v_digito := 0;
    ELSE
        v_digito := 11 - v_resto;
    END IF;

    -- Comparação com o dígito de controlo fornecido
    IF v_digito <> CAST(SUBSTRING(NEW.nif FROM 9 FOR 1) AS INTEGER) THEN
        RAISE EXCEPTION 'NIF inválido: dígito de controlo incorreto.';
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_fn_valida_nif() owner to postgres;

