create function trg_fn_valida_email_duplicado() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1 FROM contacto_email
        WHERE cliente_nif = NEW.cliente_nif
          AND email = NEW.email
          AND contacto_email_id <> COALESCE(NEW.contacto_email_id, -1)
    ) THEN
        RAISE EXCEPTION 'Contacto duplicado: o cliente ''%'' já possui o email ''%''.', NEW.cliente_nif, NEW.email;
    END IF;
    RETURN NEW;
END;
$$;

alter function trg_fn_valida_email_duplicado() owner to postgres;

