create function fx_media_movel(days integer, isin character varying) returns numeric
    language plpgsql
as
$$
DECLARE
    media NUMERIC(15,2);
BEGIN
    IF days <= 0 THEN
        RAISE EXCEPTION 'O número de dias para a média móvel deve ser superior a zero.' USING ERRCODE = '22023';
    END IF;

    SELECT ROUND(AVG(valor_fecho), 2) INTO media
    FROM (
        SELECT valor_fecho
        FROM valor_instrumento_diario
        WHERE instrumento_isin = isin
        ORDER BY data DESC
        LIMIT days
    ) subquery;

    RETURN COALESCE(media, 0.00);
END;
$$;

alter function fx_media_movel(integer, varchar) owner to postgres;

