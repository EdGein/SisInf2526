create function fx_media_movel(days integer, p_instrumento_isin character varying) returns numeric
    language plpgsql
as
$$
DECLARE
    v_media NUMERIC;
BEGIN
    SELECT AVG(valor_fecho)
    INTO v_media
    FROM (
        SELECT valor_fecho
        FROM valor_instrumento_diario
        WHERE instrumento_isin = p_instrumento_isin
        ORDER BY data DESC
        LIMIT days
    ) AS ultimos_n;

    RETURN ROUND(v_media, 2);
END;
$$;

alter function fx_media_movel(integer, varchar) owner to postgres;

