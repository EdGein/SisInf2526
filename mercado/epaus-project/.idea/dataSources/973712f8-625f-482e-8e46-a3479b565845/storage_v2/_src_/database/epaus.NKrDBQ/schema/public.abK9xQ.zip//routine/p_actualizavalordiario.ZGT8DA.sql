create procedure p_actualizavalordiario(IN p_identificador character varying, IN p_datatempo timestamp without time zone, IN p_valor numeric)
    language plpgsql
as
$$
DECLARE
    v_data DATE := p_datatempo::DATE;
BEGIN
    -- 1. Registar o triplo
    INSERT INTO triplo_externo (identificador, data_tempo, valor)
    VALUES (p_identificador, p_datatempo, p_valor)
    ON CONFLICT DO NOTHING;

    -- 2. Verificar se o instrumento existe
    IF NOT EXISTS (SELECT 1 FROM instrumento WHERE instrumento_id = p_identificador) THEN
        RETURN;
    END IF;

    -- 3. Atualizar registo diário do instrumento
    INSERT INTO valor_instrumento_diario (instrumento_isin, data, valor_minimo, valor_maximo, valor_abertura, valor_fecho)
    VALUES (p_identificador, v_data, p_valor, p_valor, p_valor, p_valor)
    ON CONFLICT (instrumento_isin, data) DO UPDATE
        SET valor_minimo = LEAST(valor_instrumento_diario.valor_minimo, EXCLUDED.valor_minimo),
            valor_maximo = GREATEST(valor_instrumento_diario.valor_maximo, EXCLUDED.valor_maximo),
            valor_fecho  = EXCLUDED.valor_fecho;

    -- 4. Atualizar dados fundamentais
    UPDATE dados_fundamentais
    SET valor_actual = p_valor
    WHERE instrumento_isin = p_identificador;
END;
$$;

alter procedure p_actualizavalordiario(varchar, timestamp, numeric) owner to postgres;

