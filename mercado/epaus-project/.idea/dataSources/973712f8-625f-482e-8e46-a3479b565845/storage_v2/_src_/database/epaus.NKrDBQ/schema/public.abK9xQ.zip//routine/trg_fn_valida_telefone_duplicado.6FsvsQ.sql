create function trg_fn_valida_telefone_duplicado() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1 FROM contacto_telefone
        WHERE cliente_nif = NEW.cliente_nif
          AND telefone = NEW.telefone
          AND contacto_telefone_id <> COALESCE(NEW.contacto_telefone_id, -1)
    ) THEN
        RAISE EXCEPTION 'Contacto duplicado: o cliente já possui este telefone.';
    END IF;
    RETURN NEW;
END;
$$;

alter function trg_fn_valida_telefone_duplicado() owner to postgres;

