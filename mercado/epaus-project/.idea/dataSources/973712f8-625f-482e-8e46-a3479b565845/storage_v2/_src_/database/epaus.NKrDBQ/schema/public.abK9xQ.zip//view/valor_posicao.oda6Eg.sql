create view valor_posicao(portefolio, instrumento_isin, quantidade, valor_actual, valor_total) as
SELECT p.portefolio,
       p.instrumento_isin,
       p.quantidade,
       df.valor_actual,
       round(p.quantidade * df.valor_actual, 2) AS valor_total
FROM posicao p
         JOIN dados_fundamentais df ON df.instrumento_isin::text = p.instrumento_isin::text;

alter table valor_posicao
    owner to postgres;

