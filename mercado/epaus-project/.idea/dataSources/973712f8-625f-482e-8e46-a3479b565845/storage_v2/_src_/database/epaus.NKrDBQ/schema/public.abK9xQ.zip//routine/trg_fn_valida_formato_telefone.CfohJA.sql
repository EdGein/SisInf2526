create function trg_fn_valida_formato_telefone() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.telefone !~ '^\+?[0-9\s\-]{9,}$' THEN
        RAISE EXCEPTION 'Telefone inválido: ''%'' não tem um formato válido (mín. 9 dígitos, pode incluir +, espaços e hífens).', NEW.telefone;
    END IF;
    RETURN NEW;
END;
$$;

alter function trg_fn_valida_formato_telefone() owner to postgres;

