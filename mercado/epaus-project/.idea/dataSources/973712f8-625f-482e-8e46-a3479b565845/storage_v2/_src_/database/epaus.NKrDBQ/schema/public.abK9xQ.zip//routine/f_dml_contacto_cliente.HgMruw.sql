create function f_dml_contacto_cliente() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- Garantir que o cliente existe
        IF NOT EXISTS (SELECT 1 FROM cliente WHERE nif = NEW.nif) THEN
            INSERT INTO cliente (nif, cartao_cidadao, nome)
            VALUES (NEW.nif, NEW.cartao_cidadao, NEW.nome);
        END IF;

        -- Inserir na tabela correta dependendo do tipo
        IF NEW.tipo_contacto = 'Email' THEN
            INSERT INTO contacto_email (cliente_nif, descricao, email)
            VALUES (NEW.nif, NEW.descricao, NEW.contacto);
        ELSEIF NEW.tipo_contacto = 'Telefone' THEN
            INSERT INTO contacto_telefone (cliente_nif, descricao, telefone)
            VALUES (NEW.nif, NEW.descricao, NEW.contacto);
        ELSE
            RAISE EXCEPTION 'Tipo de contacto desconhecido: %', NEW.tipo_contacto USING ERRCODE = '45000';
        END IF;
        RETURN NEW;

    ELSEIF TG_OP = 'UPDATE' THEN
        IF OLD.tipo_contacto = 'Email' THEN
            UPDATE contacto_email
            SET email = NEW.contacto, descricao = NEW.descricao
            WHERE contacto_email_id = OLD.contacto_id;
        ELSEIF OLD.tipo_contacto = 'Telefone' THEN
            UPDATE contacto_telefone
            SET telefone = NEW.contacto, descricao = NEW.descricao
            WHERE contacto_telefone_id = OLD.contacto_id;
        END IF;
        RETURN NEW;

    ELSEIF TG_OP = 'DELETE' THEN
        IF OLD.tipo_contacto = 'Email' THEN
            DELETE FROM contacto_email WHERE contacto_email_id = OLD.contacto_id;
        ELSEIF OLD.tipo_contacto = 'Telefone' THEN
            DELETE FROM contacto_telefone WHERE contacto_telefone_id = OLD.contacto_id;
        END IF;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;

alter function f_dml_contacto_cliente() owner to postgres;

