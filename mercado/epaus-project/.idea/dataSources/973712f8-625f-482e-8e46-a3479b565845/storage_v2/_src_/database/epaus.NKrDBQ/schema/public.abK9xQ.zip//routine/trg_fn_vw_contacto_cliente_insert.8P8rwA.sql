create function trg_fn_vw_contacto_cliente_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM cliente WHERE nif = NEW.nif) THEN
        INSERT INTO cliente (nif, cartao_cidadao, nome)
        VALUES (NEW.nif, NEW.cartao_cidadao, NEW.nome);
    END IF;

    IF NEW.tipo_contacto = 'email' THEN
        INSERT INTO contacto_email (cliente_nif, descricao, email)
        VALUES (NEW.nif, NEW.descricao, NEW.contacto);
    ELSIF NEW.tipo_contacto = 'telefone' THEN
        INSERT INTO contacto_telefone (cliente_nif, descricao, telefone)
        VALUES (NEW.nif, NEW.descricao, NEW.contacto);
    ELSE
        RAISE EXCEPTION 'Tipo de contacto inválido. Use "email" ou "telefone".';
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_fn_vw_contacto_cliente_insert() owner to postgres;

