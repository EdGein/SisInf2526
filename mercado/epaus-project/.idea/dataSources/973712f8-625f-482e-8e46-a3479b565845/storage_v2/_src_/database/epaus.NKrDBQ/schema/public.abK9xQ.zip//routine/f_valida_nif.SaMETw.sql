create function f_valida_nif() returns trigger
    language plpgsql
as
$$
DECLARE
    soma INTEGER := 0;
    resto INTEGER;
    digito_controlo INTEGER;
    i INTEGER;
BEGIN
    -- Validar tamanho e caracteres numéricos
    IF NEW.nif NOT SIMILAR TO '[0-9]{9}' THEN
        RAISE EXCEPTION 'NIF inválido: deve conter exatamente 9 dígitos.' USING ERRCODE = '45000';
    END IF;

    -- Validar dígito inicial permitido
    IF SUBSTRING(NEW.nif FROM 1 FOR 1) NOT IN ('1', '2', '3', '5', '6', '8', '9') THEN
        RAISE EXCEPTION 'NIF inválido: dígito inicial não permitido.' USING ERRCODE = '45000';
    END IF;

    -- Cálculo do algoritmo módulo 11
    FOR i IN 1..8 LOOP
        soma := soma + (CAST(SUBSTRING(NEW.nif FROM i FOR 1) AS INTEGER) * (10 - i));
    END LOOP;

    resto := soma % 11;
    IF resto < 2 THEN
        digito_controlo := 0;
    ELSE
        digito_controlo := 11 - resto;
    END IF;

    IF CAST(SUBSTRING(NEW.nif FROM 9 FOR 1) AS INTEGER) <> digito_controlo THEN
        RAISE EXCEPTION 'NIF inválido: dígito de controlo incorreto.' USING ERRCODE = '45000';
    END IF;

    RETURN NEW;
END;
$$;

alter function f_valida_nif() owner to postgres;

