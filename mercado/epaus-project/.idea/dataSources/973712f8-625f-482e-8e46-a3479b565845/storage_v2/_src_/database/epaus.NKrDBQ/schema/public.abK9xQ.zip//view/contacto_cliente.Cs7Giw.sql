create view contacto_cliente (nif, cartao_cidadao, nome, tipo_contacto, contacto, descricao, contacto_id) as
SELECT c.nif,
       c.cartao_cidadao,
       c.nome,
       'Email'::character varying(10) AS tipo_contacto,
       e.email                        AS contacto,
       e.descricao,
       e.contacto_email_id            AS contacto_id
FROM cliente c
         JOIN contacto_email e ON c.nif::text = e.cliente_nif::text
UNION ALL
SELECT c.nif,
       c.cartao_cidadao,
       c.nome,
       'Telefone'::character varying(10) AS tipo_contacto,
       t.telefone                        AS contacto,
       t.descricao,
       t.contacto_telefone_id            AS contacto_id
FROM cliente c
         JOIN contacto_telefone t ON c.nif::text = t.cliente_nif::text;

alter table contacto_cliente
    owner to postgres;

