create view contacto_cliente(nif, cartao_cidadao, nome, tipo_contacto, contacto, descricao) as
SELECT c.nif,
       c.cartao_cidadao,
       c.nome,
       'email'::character varying AS tipo_contacto,
       ce.email                   AS contacto,
       ce.descricao
FROM cliente c
         JOIN contacto_email ce ON c.nif::text = ce.cliente_nif::text
UNION ALL
SELECT c.nif,
       c.cartao_cidadao,
       c.nome,
       'telefone'::character varying AS tipo_contacto,
       ct.telefone                   AS contacto,
       ct.descricao
FROM cliente c
         JOIN contacto_telefone ct ON c.nif::text = ct.cliente_nif::text;

alter table contacto_cliente
    owner to postgres;

