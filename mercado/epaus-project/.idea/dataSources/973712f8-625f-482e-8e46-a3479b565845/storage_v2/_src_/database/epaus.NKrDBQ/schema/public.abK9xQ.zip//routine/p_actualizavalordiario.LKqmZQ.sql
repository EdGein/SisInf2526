create procedure p_actualizavalordiario()
    language plpgsql
as
$$
DECLARE
    r RECORD;
BEGIN
    -- 1. Consolidar triplos: calcular min, max, abertura e fecho por instrumento/dia
    --    Usar funções de janela para obter o primeiro e último valor do dia,
    --    evitando subqueries correlacionadas que o PostgreSQL não suporta em GROUP BY.
    FOR r IN (
        SELECT
            identificador                                   AS isin,
            data_tempo::DATE                                AS data_dia,
            MIN(valor)                                      AS val_min,
            MAX(valor)                                      AS val_max,
            -- FIRST_VALUE sobre a janela ordenada por data_tempo ASC = valor de abertura
            MIN(valor) FILTER (WHERE rn_asc  = 1)          AS val_abertura,
            -- LAST_VALUE  sobre a janela ordenada por data_tempo DESC = valor de fecho
            MIN(valor) FILTER (WHERE rn_desc = 1)          AS val_fecho
        FROM (
            SELECT
                identificador,
                data_tempo,
                valor,
                ROW_NUMBER() OVER (
                    PARTITION BY identificador, data_tempo::DATE
                    ORDER BY data_tempo ASC
                ) AS rn_asc,
                ROW_NUMBER() OVER (
                    PARTITION BY identificador, data_tempo::DATE
                    ORDER BY data_tempo DESC
                ) AS rn_desc
            FROM triplo_externo
        ) ranked
        GROUP BY identificador, data_tempo::DATE
    ) LOOP
        -- Upsert em valor_instrumento_diario
        INSERT INTO valor_instrumento_diario
            (instrumento_isin, data, valor_minimo, valor_maximo, valor_abertura, valor_fecho)
        VALUES
            (r.isin, r.data_dia, r.val_min, r.val_max, r.val_abertura, r.val_fecho)
        ON CONFLICT (instrumento_isin, data) DO UPDATE
        SET valor_minimo  = LEAST(valor_instrumento_diario.valor_minimo, r.val_min),
            valor_maximo  = GREATEST(valor_instrumento_diario.valor_maximo, r.val_max),
            valor_fecho   = r.val_fecho;

        -- Atualizar dados_fundamentais com o valor atual (fecho mais recente)
        INSERT INTO dados_fundamentais
            (instrumento_isin, variacao_diaria, valor_actual,
             media_6_meses, variacao_6_meses,
             percentagem_variacao_diaria, percentagem_variacao_6_meses)
        VALUES
            (r.isin, r.val_max - r.val_min, r.val_fecho, r.val_fecho, 0, 0, 0)
        ON CONFLICT (instrumento_isin) DO UPDATE
        SET valor_actual    = r.val_fecho,
            variacao_diaria = r.val_max - r.val_min;
    END LOOP;

    -- 2. Recalcular valor_mercado_diario
    INSERT INTO valor_mercado_diario (mercado, data, valor_indice, valor_abertura, variacao_diaria)
    SELECT
        i.mercado,
        vid.data,
        SUM(vid.valor_fecho)    AS valor_indice,
        SUM(vid.valor_abertura) AS valor_abertura,
        0                       AS variacao_diaria
    FROM valor_instrumento_diario vid
    JOIN instrumento i ON vid.instrumento_isin = i.instrumento_id
    GROUP BY i.mercado, vid.data
    ON CONFLICT (mercado, data) DO UPDATE
    SET valor_indice = EXCLUDED.valor_indice;
END;
$$;

alter procedure p_actualizavalordiario() owner to postgres;

