create function fx_portefolio_info(p_portfolio_id bigint)
    returns TABLE(isin character varying, quantidade numeric, valor_atual numeric, perc_variacao numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        p.instrumento_isin AS isin,
        p.quantidade,
        df.valor_actual AS valor_atual,
        ROUND(
            CASE
                WHEN vd.valor_abertura IS NOT NULL AND vd.valor_abertura <> 0
                THEN ((df.valor_actual - vd.valor_abertura) / vd.valor_abertura) * 100
                ELSE 0
            END,
        2) AS perc_variacao
    FROM posicao p
    JOIN dados_fundamentais df ON p.instrumento_isin = df.instrumento_isin
    LEFT JOIN valor_instrumento_diario vd
        ON p.instrumento_isin = vd.instrumento_isin AND vd.data = CURRENT_DATE
    WHERE p.portefolio = p_portfolio_id;
END;
$$;

alter function fx_portefolio_info(bigint) owner to postgres;

