create function fx_portefolio_info(p_id bigint)
    returns TABLE(isin character varying, quantidade numeric, valor_actual numeric, variacao_percentual numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        pos.instrumento_isin,
        pos.quantidade,
        df.valor_actual,
        ROUND(
            CASE
                WHEN fecho_anterior.valor_fecho IS NULL OR fecho_anterior.valor_fecho = 0 THEN 0.00
                ELSE ((df.valor_actual - fecho_anterior.valor_fecho) / fecho_anterior.valor_fecho) * 100
            END,
            2
        ) AS variacao_percentual
    FROM posicao pos
    JOIN dados_fundamentais df ON pos.instrumento_isin = df.instrumento_isin
    LEFT JOIN LATERAL (
        SELECT vid.valor_fecho
        FROM valor_instrumento_diario vid
        WHERE vid.instrumento_isin = pos.instrumento_isin
        ORDER BY vid.data DESC
        LIMIT 1 OFFSET 1 -- Obtém o segundo registo mais recente (dia anterior)
    ) fecho_anterior ON TRUE
    WHERE pos.portefolio = p_id;
END;
$$;

alter function fx_portefolio_info(bigint) owner to postgres;

