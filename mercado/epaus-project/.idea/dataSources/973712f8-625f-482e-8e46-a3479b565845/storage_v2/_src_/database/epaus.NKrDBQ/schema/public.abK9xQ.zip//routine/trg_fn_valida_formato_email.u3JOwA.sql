create function trg_fn_valida_formato_email() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.email !~ '^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$' THEN
        RAISE EXCEPTION 'Email inválido: ''%'' não tem um formato válido (esperado: utilizador@dominio.ext).', NEW.email;
    END IF;
    RETURN NEW;
END;
$$;

alter function trg_fn_valida_formato_email() owner to postgres;

